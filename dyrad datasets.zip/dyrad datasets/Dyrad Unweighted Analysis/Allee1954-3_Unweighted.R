
library(plyr)
library(readr)
library(ggplot2)
library(GGally)
library(dplyr)
library(mlbench)
library(lattice)
library(caret)
library("readxl")
library(CGPfunctions)
library(ggrepel)
library(scales)
theme_set(theme_classic())
bon <- read_xlsx("/Users/yuanjiajie/Desktop/G20 Dataset/__G20_all_Unweighted_CON-score-vs-PageRank.xlsx")

### Observation
glimpse(bon)
bon1 <- data.frame(bon$ID,bon$`CON score`,bon$`Page Rank`)
bon1 <- na.omit(bon1)
### Normalize CON score 0-1
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}
unweightedcon <- normalize(bon1$bon..CON.score.)
unweightedPR <- normalize(bon1$bon..Page.Rank.)


### Boxplots comparison

boxplot(unweightedcon, unweightedPR,
        names = c("UnCON", "UnPR"))

summary(unweightedcon)

summary(unweightedPR)


### Slope Graph
bon1$CON.scores..unweighted.<-unweightedcon

bon1$PageRank..unweighted. <-unweightedPR


left_label <- paste(bon1$bon.ID, round(bon1$CON.scores..unweighted., digits = 3), sep=", ")
right_label <- paste(bon1$bon.ID, round(bon1$PageRank..unweighted., digits = 3),sep=", ")
bon1$class <- ifelse((bon1$PageRank..unweighted. - bon1$CON.scores..unweighted.) < 0, "green", "red")

## plot(Unweighted Compare)
p <- ggplot(bon1) + geom_segment(aes(x=1, xend=2, y= CON.scores..unweighted., yend=PageRank..unweighted., col=class), size=.75, show.legend=F) +
  geom_vline(xintercept=1, linetype="dashed", size=.1) + 
  geom_vline(xintercept=2, linetype="dashed", size=.1) +
  scale_color_manual(labels = c("Up", "Down"), 
                     values = c("green"="#00ba38", "red"="#f8766d")) +
  labs(x="", y="Gap") +  # Axis labels
  xlim(.5, 2.5) + ylim(0,(1.1*(max(bon1$CON.scores..unweighted., bon1$PageRank..unweighted.))))

p <- p + geom_text(label=left_label, y=bon1$CON.scores..unweighted., x=rep(1, NROW(bon1)), hjust=1.1, size=3.5)
p <- p + geom_text(label=right_label, y=bon1$PageRank..unweighted., x=rep(2, NROW(bon1)), hjust=-0.1, size=3.5)
p <- p + geom_text(label=" Unweighted CON ", x=1, y=1.1*(max(bon1$CON.scores..unweighted., bon1$PageRank..unweighted.)), hjust=1.1, size=3)  # title
p <- p + geom_text(label=" Unweighted PR ", x=2, y=1.1*(max(bon1$CON.scores..unweighted., bon1$PageRank..unweighted.)), hjust=-0.1, size=3)  # title
p


### Lollipop Chart (Unweighted)
bon1$UnDiff <- abs(bon1$CON.scores..unweighted. - bon1$PageRank..unweighted.)


ggplot(bon1, aes(x=bon.ID, y=UnDiff)) + 
  geom_point(size=3) + 
  geom_segment(aes(x=bon.ID, 
                   xend=bon.ID, 
                   y=0, 
                   yend=1)) + 
  labs(title="Lollipop Chart", 
       subtitle="Unweighted Difference between Con Score & PageRank Score", 
       caption="source: bonanni") + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6))


