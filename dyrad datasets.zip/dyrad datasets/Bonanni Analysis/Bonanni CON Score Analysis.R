bon <- read.csv("/Users/yuanjiajie/Downloads/Bonanni2007-2 analysis_.csv")
library(plyr)
library(readr)
library(ggplot2)
library(GGally)
library(dplyr)
library(mlbench)
library(lattice)
library(caret)
library("readxl")
library(CGPfunctions)
library(ggrepel)
library(scales)
theme_set(theme_classic())


### Observation
glimpse(bon)
bon1 <- na.omit(bon)

### Normalize CON score 0-1
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}
unweightedcon <- normalize(bon1$CON.scores..unweighted.)
weightedcon<- normalize(bon1$CON.Scores..weighted.)
UnPR <- normalize(bon1$PageRank..unweighted.)
PR <- normalize(bon1$PageRank.weighted.)

### Boxplots comparison
unweightedPR <- UnPR
weightedPR <- PR

boxplot(unweightedcon, weightedcon, unweightedPR, weightedPR,
        names = c("UnCON", "CON", "UnPR", "PR"))

summary(unweightedcon)
summary(weightedcon)
summary(unweightedPR)
summary(weightedPR)

### Slope Graph
bon1$CON.scores..unweighted.<-unweightedcon
bon1$CON.Scores..weighted.<-weightedcon
bon1$PageRank..unweighted. <-unweightedPR
bon1$PageRank.weighted. <- weightedPR

left_label <- paste(bon1$X, round(bon1$CON.scores..unweighted., digits = 3), sep=", ")
right_label <- paste(bon1$X, round(bon1$PageRank..unweighted., digits = 3),sep=", ")
bon1$class <- ifelse((bon1$PageRank..unweighted. - bon1$CON.scores..unweighted.) < 0, "red", "green")
## plot(Unweighted Compare)
p <- ggplot(bon1) + geom_segment(aes(x=1, xend=2, y= CON.scores..unweighted., yend=PageRank..unweighted., col=class), size=.75, show.legend=F) +
  geom_vline(xintercept=1, linetype="dashed", size=.1) + 
  geom_vline(xintercept=2, linetype="dashed", size=.1) +
  scale_color_manual(labels = c("Up", "Down"), 
                     values = c("green"="#00ba38", "red"="#f8766d")) +
  labs(x="", y="Gap") +  # Axis labels
  xlim(.5, 2.5) + ylim(0,(1.1*(max(bon1$CON.scores..unweighted., bon1$PageRank..unweighted.))))

p <- p + geom_text(label=left_label, y=bon1$CON.scores..unweighted., x=rep(1, NROW(bon1)), hjust=1.1, size=3.5)
p <- p + geom_text(label=right_label, y=bon1$PageRank..unweighted., x=rep(2, NROW(bon1)), hjust=-0.1, size=3.5)
p <- p + geom_text(label=" Unweighted CON ", x=1, y=1.1*(max(bon1$CON.scores..unweighted., bon1$PageRank..unweighted.)), hjust=1.1, size=3)  # title
p <- p + geom_text(label=" Unweighted PR ", x=2, y=1.1*(max(bon1$CON.scores..unweighted., bon1$PageRank..unweighted.)), hjust=-0.1, size=3)  # title
p

## plot(Weighted Compare)
left_label <- paste(bon1$X, round(bon1$CON.Scores..weighted., digits = 3), sep=", ")
right_label <- paste(bon1$X, round(bon1$PageRank.weighted., digits = 3),sep=", ")
bon1$class <- ifelse((bon1$PageRank.weighted. - bon1$CON.Scores..weighted.) < 0, "red", "green")

p <- ggplot(bon1) + geom_segment(aes(x=1, xend=2, y= CON.Scores..weighted., yend=PageRank.weighted., col=class), size=.75, show.legend=F) +
  geom_vline(xintercept=1, linetype="dashed", size=.1) + 
  geom_vline(xintercept=2, linetype="dashed", size=.1) +
  scale_color_manual(labels = c("Up", "Down"), 
                     values = c("green"="#00ba38", "red"="#f8766d")) +
  labs(x="", y="Gap") +  # Axis labels
  xlim(.5, 2.5) + ylim(0,(1.1*(max(bon1$CON.Scores..weighted., bon1$PageRank.weighted.))))

p <- p + geom_text(label=left_label, y=bon1$CON.Scores..weighted., x=rep(1, NROW(bon1)), hjust=1.1, size=3.5)
p <- p + geom_text(label=right_label, y=bon1$PageRank.weighted., x=rep(2, NROW(bon1)), hjust=-0.1, size=3.5)
p <- p + geom_text(label=" weighted CON ", x=1, y=1.1*(max(bon1$CON.Scores..weighted., bon1$PageRank.weighted.)), hjust=1.1, size=3)  # title
p <- p + geom_text(label=" weighted PR ", x=2, y=1.1*(max(bon1$CON.Scores..weighted., bon1$PageRank.weighted.)), hjust=-0.1, size=3)  # title
p

### Lollipop Chart (Unweighted)
bon1$UnDiff <- abs(bon1$CON.scores..unweighted. - bon1$PageRank..unweighted.)
bon1$WeDiff <- abs(bon1$CON.Scores..weighted. - bon1$PageRank.weighted.)

ggplot(bon1, aes(x=bon1$X, y=bon1$UnDiff)) + 
  geom_point(size=3) + 
  geom_segment(aes(x=bon1$X, 
                   xend=bon1$X, 
                   y=0, 
                   yend=1)) + 
  labs(title="Lollipop Chart", 
       subtitle="Unweighted Difference between Con Score & PageRank Score", 
       caption="source: bonanni",
       y = "Difference",
       x = "Variable") + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6))

## Lollipop Chart (Weighted)
ggplot(bon1, aes(x=bon1$X, y=bon1$WeDiff)) + 
  geom_point(size=3) + 
  geom_segment(aes(x=bon1$X, 
                   xend=bon1$X, 
                   y=0, 
                   yend=1)) + 
  labs(title="Lollipop Chart", 
       subtitle="Weighted Difference between Con Score & PageRank Score", 
       caption="source: bonanni",
       y = "Difference",
       x = "Variable") + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6))







