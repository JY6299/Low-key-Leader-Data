
library(plyr)
library(readr)
library(ggplot2)
library(GGally)
library(dplyr)
library(mlbench)
library(lattice)
library(caret)
library("readxl")
library(CGPfunctions)
library(ggrepel)
library(scales)
theme_set(theme_classic())
bon <- read_xlsx("/Users/yuanjiajie/Desktop/G20 Dataset/__G20_all_Weighted_CON-score-vs-PageRank.xlsx")

### Observation
glimpse(bon)
bon1 <- data.frame(bon$ID,bon$`CON score`,bon$`Page Rank`)
bon1 <- na.omit(bon1)

### Normalize CON score 0-1
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

weightedcon<- normalize(bon1$bon..CON.score.)

weightedPR <- normalize(bon1$bon..Page.Rank.)

### Boxplots comparison

boxplot(weightedcon, weightedPR,
        names = c("CON", "PR"))


summary(weightedcon)

summary(weightedPR)

### Slope Graph

bon1$CON.Scores..weighted.<-weightedcon

bon1$PageRank.weighted. <- weightedPR

## plot(Weighted Compare)
left_label <- paste(bon1$bon.ID, round(bon1$CON.Scores..weighted., digits = 3), sep=", ")
right_label <- paste(bon1$bon.ID, round(bon1$PageRank.weighted., digits = 3),sep=", ")
bon1$class <- ifelse((bon1$PageRank.weighted. - bon1$CON.Scores..weighted.) < 0, "red", "green")

p <- ggplot(bon1) + geom_segment(aes(x=1, xend=2, y= CON.Scores..weighted., yend=PageRank.weighted., col=class), size=.75, show.legend=F) +
  geom_vline(xintercept=1, linetype="dashed", size=.1) + 
  geom_vline(xintercept=2, linetype="dashed", size=.1) +
  scale_color_manual(labels = c("Up", "Down"), 
                     values = c("green"="#00ba38", "red"="#f8766d")) +
  labs(x="", y="Gap") +  # Axis labels
  xlim(.5, 2.5) + ylim(0,(1.1*(max(bon1$CON.Scores..weighted., bon1$PageRank.weighted.))))

p <- p + geom_text(label=left_label, y=bon1$CON.Scores..weighted., x=rep(1, NROW(bon1)), hjust=1.1, size=3.5)
p <- p + geom_text(label=right_label, y=bon1$PageRank.weighted., x=rep(2, NROW(bon1)), hjust=-0.1, size=3.5)
p <- p + geom_text(label=" weighted CON ", x=1, y=1.1*(max(bon1$CON.Scores..weighted., bon1$PageRank.weighted.)), hjust=1.1, size=3)  # title
p <- p + geom_text(label=" weighted PR ", x=2, y=1.1*(max(bon1$CON.Scores..weighted., bon1$PageRank.weighted.)), hjust=-0.1, size=3)  # title
p

### Lollipop Chart (Unweighted)
bon1$WeDiff <- abs(bon1$CON.Scores..weighted. - bon1$PageRank.weighted.)

## Lollipop Chart (Weighted)
ggplot(bon1, aes(x=bon.ID, y=WeDiff)) + 
  geom_point(size=3) + 
  geom_segment(aes(x=bon.ID, 
                   xend=bon.ID, 
                   y=0, 
                   yend=1)) + 
  labs(title="Lollipop Chart", 
       subtitle="Weighted Difference between Con Score & PageRank Score", 
       caption="source: bonanni") + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6))


